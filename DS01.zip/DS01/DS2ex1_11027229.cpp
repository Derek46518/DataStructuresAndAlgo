// C++ 11
// 11027229 & 11027232���p�@�~
#include<iostream>
#include<vector>
#include<sstream>
#include<fstream>
#include<string>
#include<cmath>
using namespace std;
// abstract class
// use to define stuff 
class Heap {
	public:
		virtual void insert(vector<string> data) {
		}
		virtual void del() {

		}
		virtual void heapify(int i) {

		}
		virtual void printOut() {

		}
};
// class of Min Heap
class MinHeap:public Heap {
	public:
		
		MinHeap() {}
		
		/**
 		* Insert data into heap.
 		*
 		* 
 		* @param vector of strings.
 		* 
 		*/
		void insert(vector<string> dataT) {
			data.push_back(dataT);
			int i = data.size()-1;
			while (i != 0 && key(parent(i)) > key(i)) {
				swap(i, parent(i));
				i = parent(i);
			}
		}
		
		/**
 		* Print out data in specific format.
 		*
 		* 
 		* 
 		* 
 		*/
		void printOut() {
			printf("<min heap>\n");
			printf("root: [%s] %s\n",data[0][11].c_str(),data[0][8].c_str());
			printf("bottom: [%s] %s\n",data[data.size()-1][11].c_str(),data[data.size()-1][8].c_str());
			int i = 0;
			while(left(i)<data.size()) i = left(i);
			printf("leftmost bottom: [%s] %s\n",data[i][11].c_str(),data[i][8].c_str());
			data.clear();

		}

		void heapify(int i) {}
	private:
		vector<vector<string> > data;
		/**
 		* Get the parent of the index
 		*
 		* 
 		* @param index.
 		* @return parent.
 		*/
		int parent(int i) {
			return (i-1)/2;
		}
		/**
 		* Get the left node of the index
 		*
 		* 
 		* @param index.
 		* @return left.
 		*/
		int left(int i) {
			return (2*i + 1);
		}
		/**
 		* Get the right node of the index
 		*
 		* 
 		* @param index.
 		* @return right.
 		*/
		int right(int i) {
			return (2*i + 2);
		}
		/**
 		* Get the key to the specific index
 		*
 		* 
 		* @param index.
 		* @return key.
 		*/
		int key(int i) {
			return stoi(data[i][8]);
		}
		/**
 		* Swap two orders
 		*
 		* 
 		* @param index i and j.
 		*
 		*/
		void swap(int i, int j) {
			vector<string > temp = data[i];
			data[i] = data[j];
			data[j] = temp;
		}
};

class MinMaxHeap:public Heap {
	public:

		
		MinMaxHeap() {}
		
		void insert(vector<string> dataT) {
			data.push_back(dataT);
			int index = data.size()-1;
			bubbleUp(index); // Bubble up every insert
		}

		void printOut() {
			printf("<min-max heap>\n");
			printf("root: [%s] %s\n",data[0][11].c_str(),data[0][8].c_str());
			printf("bottom: [%s] %s\n",data[data.size()-1][11].c_str(),data[data.size()-1][8].c_str());
			int i = 0;
			while(left(i)<data.size()) i = left(i);
			printf("leftmost bottom: [%s] %s\n",data[i][11].c_str(),data[i][8].c_str());
			data.clear();

		}
		
		void heapify(int i) {

		}
	private:
		vector<vector<string> > data;
		int parent(int i) {
			return (i-1)/2;
		}
		/**
 		* Get grandparent by index
 		*
 		* 
 		* @param index.
 		*
 		*/
		int grandparent(int i) {
			return parent(parent(i));
		}
		 
		int left(int i) {
			return (2*i + 1);
		}

		int right(int i) {
			return (2*i + 2);
		}

		int key(int i) {
			return stoi(data[i][8]);
		}
		/**
 		* Determine that the level is min or not
 		*
 		* 
 		* @param index.
 		* @return boolean, true if is Min level.
 		*/
		bool isMinLevel(int i) {
        	int level = log2(i+1);
        	return (level % 2 == 0);
    	}
    	
    	void swap(int i, int j) {
			vector<string > temp = data[i];
			data[i] = data[j];
			data[j] = temp;
		}
		
		/**
 		* Bubble up the index
 		* 
 		* 
 		* @param index.
 		* 
 		*/
		void bubbleUp(int i){
			if(i==0) return;
			if(isMinLevel(i)){
				if(key(i)>key(parent(i))){
					swap(i,parent(i));
					bubbleUpMax(parent(i));
				}
				else bubbleUpMin(i);
			}
			else{
				if(key(i)<key(parent(i))){
					
					swap(i,parent(i));
					bubbleUpMin(parent(i));
				}
				else bubbleUpMax(i);
			}
			
		}
		void bubbleUpMin(int i) {
        	if (i < 2) return;
        	if (isMinLevel(grandparent(i)) && key(i) < key(grandparent(i))) {
            	swap(i, grandparent(i));
            	bubbleUpMin(grandparent(i));
        	}
    	}
    	
    	void bubbleUpMax(int i){
    		if (i < 2) return;
        	if (!isMinLevel(grandparent(i)) && key(i) > key(grandparent(i))) {
            	swap(i, grandparent(i));
            	bubbleUpMax(grandparent(i));
        	}
		}

};

vector<string> split(string &str, string &b) {
	int first, last; //�O���Ĥ@�Ӧ�m�M�ĤG��
	int i = 0; // �p��0
	vector<string> answer; // ����
	last = str.find(b); // ���h�M��b���Ӧ�m�n����
	first = 0;// �@�}�l
	// ��last�٨S�]�쵲������m
	while (last != string::npos) {
		
		
		// ��substring���Janswer
		answer.push_back(str.substr(first, last - first)); 
	
		// first����last�[�W���ξ����j�p
		first = last + b.size();
		// �A�~��M��U�ӭn���Ϊ��I
		last = str.find(b, first);
		i++;
	}

	// �p�Gfirst����m���O�̫�@�Ӧr�� �N��first�᭱�����e����answer�̭�
	if (first != str.length()) {
		answer.push_back(str.substr(first));
	}
	// �^��answer
	return answer;
}

// �[�W�ɮצW�٫e��
string addPrefix(string add, string s) {
	stringstream ss;
	ss << add;
	ss << s;
	ss << ".txt";
	return ss.str();
}

// Ū��
bool readData(Heap & data, string dataName) {
	if(dataName.size()==3) dataName = addPrefix("input",dataName);
	ifstream ifs;
	string line;
	ifs.open(dataName);

	if(!ifs.is_open()) {
		printf("No file\n");
		return false;
	}
	for(int i = 0 ; i < 3 ; i++) {
		getline(ifs,line);
	}
	vector<string> temp;
	string sp = "\t";
	// �}�lŪ�� �g�Jvector��
	int i = 1;
	while(getline(ifs,line)) {

		temp = split(line,sp);
		temp.push_back(to_string(i));

		data.insert(temp);
		i++;
	}
	return true;
}

// ���o�ϥΪ̿�J��int
int getInt() {
	// ��Ū���
	string s;
	getline(cin,s);
	int total = 0; // total
	int a; // �Ȧs���Ʀr
	if(s.length()==0) return -1; // �p�G�ϥΪ̪������Uenter �N�^��-1(����main�ɷ|���ϥΪ̿�J���~)
	// string to integer
	for(int i = 0 ; i < s.length(); i++) {
		total *= 10;
		a = s[i] - '0';
		if (a < 0 || a > 9) return -1; // �p�G���b�d�� �N�^��-1 (����main�ɷ|���ϥΪ̿�J���~)
		total += a;
	}
	return total; //�N�Ȧ^�Ǧ^�h
}


int main() {

	vector<vector<string> > data;
	printf("�п�J:\n0:�h�X\n1:�إ�min heap\n2:�إ�min-max heap\n");
	int n = getInt();
	string fileName;
	MinHeap minHeap;
	MinMaxHeap minMaxHeap;
	int t ;
	while(n!=0) {
		switch(n) {
			case 1:
				printf("�п�J�ɮצW��\n");
				getline(cin,fileName);
				if(!readData(minHeap,fileName)) break;
				minHeap.printOut();
				break;
			case 2:
				printf("�п�J�ɮצW��\n");
				getline(cin,fileName);
				if(!readData(minMaxHeap,fileName)) break;
				minMaxHeap.printOut();
				break;

			default:
				printf("��J���~ �Э��s��J\n");
		}
		printf("�п�J:\n0:�h�X\n1:�إ�min heap\n2:�إ�min-max heap\n");
		n = getInt(); // ���s���Ʀr
	}
	return 0; // �n�ߺD�O�o�i��
}
